package com.example.myorchestrationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyOrchestrationServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
