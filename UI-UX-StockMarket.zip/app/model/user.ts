export class User {
    id: string;
    name: string;
    companyEmail: string;
    companyCeo: string;
}
